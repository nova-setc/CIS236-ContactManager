﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.RegularExpressions;

namespace ContactManager.Models
{
    public class Contact
    {
        [Key] public int ContactId { get; set; }

        [Required, Display(Name = "First Name"), StringLength(60)]
        public string FirstName { get; set; } = "";

        [Required, Display(Name = "Last Name"), StringLength(60)]
        public string LastName { get; set; } = "";

        [Display(Name = "Organization")]
        public string? Organization { get; set; }

        [Required, Phone]
        public string Phone { get; set; } = "";

        [Required, EmailAddress]
        public string Email { get; set; } = "";

        [Display(Name = "Category")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select a category.")]
        public int CategoryId { get; set; }
        public Category? Category { get; set; }

        [Display(Name = "Date Added")]
        public DateTime DateAdded { get; set; }

        [NotMapped]
        public string Slug
        {
            get
            {
                var s = $"{FirstName}-{LastName}".ToLowerInvariant();
                s = Regex.Replace(s, @"\s+", "-");
                s = Regex.Replace(s, @"[^a-z0-9\-]", "");
                return s;
            }
        }
    }
}

