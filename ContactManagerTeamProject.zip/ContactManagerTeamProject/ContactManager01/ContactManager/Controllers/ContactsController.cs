﻿using ContactManager.Data;
using ContactManager.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace ContactManager.Controllers
{
    public class ContactsController : Controller
    {
        private readonly AppDbContext _db;
        public ContactsController(AppDbContext db) => _db = db;

        public async Task<IActionResult> Index()
        {
            var list = await _db.Contacts.Include(c => c.Category)
                        .OrderBy(c => c.LastName).ThenBy(c => c.FirstName).ToListAsync();
            return View(list);
        }

        public async Task<IActionResult> Details(int id, string? slug)
        {
            var contact = await _db.Contacts.Include(c => c.Category)
                              .FirstOrDefaultAsync(c => c.ContactId == id);
            if (contact == null) return NotFound();
            if (!string.Equals(slug, contact.Slug, StringComparison.OrdinalIgnoreCase))
                return RedirectToAction(nameof(Details), new { id, slug = contact.Slug });
            return View(contact);
        }

        public IActionResult Create()
        {
            Categories();
            return View("EditCreate", new Contact());
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Contact contact, string? cancel)
        {
            if (!string.IsNullOrEmpty(cancel)) return RedirectToAction(nameof(Index));

            if (!ModelState.IsValid) { Categories(); return View("EditCreate", contact); }

            contact.DateAdded = DateTime.UtcNow;
            _db.Add(contact);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Details), new { id = contact.ContactId, slug = contact.Slug });
        }

        public async Task<IActionResult> Edit(int id)
        {
            var c = await _db.Contacts.FindAsync(id);
            if (c == null) return NotFound();
            Categories(c.CategoryId);
            return View("EditCreate", c);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Contact contact, string? cancel)
        {
            if (!string.IsNullOrEmpty(cancel))
                return RedirectToAction(nameof(Details), new { id, slug = contact.Slug });

            if (id != contact.ContactId) return BadRequest();
            if (!ModelState.IsValid) { Categories(contact.CategoryId); return View("EditCreate", contact); }

            _db.Entry(contact).Property(x => x.DateAdded).IsModified = false;
            _db.Update(contact);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Details), new { id = contact.ContactId, slug = contact.Slug });
        }

        public async Task<IActionResult> Delete(int id)
        {
            var c = await _db.Contacts.Include(x => x.Category)
                        .FirstOrDefaultAsync(x => x.ContactId == id);
            if (c == null) return NotFound();
            return View(c);
        }

        [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var c = await _db.Contacts.FindAsync(id);
            if (c != null) { _db.Contacts.Remove(c); await _db.SaveChangesAsync(); }
            return RedirectToAction(nameof(Index));
        }

        void Categories(int? selected = null) =>
            ViewBag.Categories = new SelectList(_db.Categories.OrderBy(c => c.Name),
                                nameof(Category.CategoryId), nameof(Category.Name), selected);
    }
}

